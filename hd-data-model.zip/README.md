1. 安装python3.7
2. 打开命令行
3. cd到hd-data-model
4. pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple some-package
5. python website.py
6. 浏览器中输入 'http://127.0.0.1:5000/'
7. 根据指引上传符合格式的数据
8. 输出结果